# RGodbeat Studio - Guion de video

Edición 02 - 10 octubre 2026.

PRODUCCIÓN AUDIOVISUAL

Video de presentación

RGodbeat Studio | Concepto: “De la idea a tu próxima canción”. Duración: 60 segundos.


---

## Página 01: Video de presentación


| DECISIÓN | PROPUESTA DE PRODUCCIÓN |
| --- | --- |
| Objetivo | Mostrar un recorrido creíble: cargar beat > grabar voz > editar > ajustar FX > guardar/exportar. |
| Público | Artistas independientes que quieren desarrollar una canción sobre un instrumental. |
| Formato principal | 16:9, 1920 x 1080, 30 fps. Versión vertical independiente en 1080 x 1920; no recortes toda la interfaz a ciegas. |
| Estilo | Negro y grafito, acentos ámbar, detalles morados. Cámara estable, luz cálida, transiciones breves y tipografía limpia. |
| Material principal | Captura real de Studio. IA para el ambiente, micrófono o planos de cierre. Logo y textos exactos añadidos en edición. |

Prepara estos materiales

**Audio:** un instrumental autorizado y una frase vocal propia. **Producto:** grabaciones de las dos vistas, carga del beat, FX y exportación. **Marca:** logo original. **Montaje:** locución separada, subtítulos y cierre con la ruta de Studio.

**Capturas incluidas**
Los PNG del kit muestran la interfaz local real en modo demo; la toma visible usa un tono sintético de prueba. Sirven para preparar la producción. Para el anuncio final, graba una voz musical real y usa un pase activo para mostrar las funciones de pago en funcionamiento.

Tiempo en pantalla: aproximadamente 47 segundos de producto y 13 de apertura/cierre. La interfaz es la protagonista.

STORYBOARD / 00:00-00:26

Presenta y demuestra

Los tiempos son objetivos de montaje. Genera los planos de IA por separado y recórtalos al editar.


---

## Página 02: Presenta y demuestra


00:00-00:05  /  La idea

**Plano y acción.** Plano corto de micrófono y audífonos, luz ámbar lateral y fondo grafito. Acercamiento suave. IA o rodaje real; ningún botón inventado.

**Locución.** “Esa idea que tienes merece escucharse.”

**Texto en pantalla.** TU PRÓXIMA CANCIÓN EMPIEZA AQUÍ

00:05-00:11  /  El producto

**Plano y acción.** Corte a una captura real de Grabador. Entra el logo original como gráfico. Enmarca el reproductor y los controles, sin ocultarlos.

**Locución.** “RGodbeat Studio reúne tu beat y tu voz en un mismo espacio.”

**Texto en pantalla.** RGODBEAT STUDIO

00:11-00:18  /  El beat

**Plano y acción.** Abre el icono de nota musical. Muestra Subir Beat y selecciona el archivo autorizado. Corte limpio al beat ya cargado; conserva el título y BPM reales.

**Locución.** “Elige una pista del catálogo o carga tu propio instrumental.”

**Texto en pantalla.** ELIGE TU BEAT

00:18-00:26  /  La toma

**Plano y acción.** Selecciona Lead 1, activa conteo y pulsa REC. Muestra brevemente el medidor y el resultado tras STOP. La voz escuchada corresponde a esa toma.

**Locución.** “Selecciona tu canal, activa el conteo y graba tu primera toma.”

**Texto en pantalla.** GRABA TU VOZ

STORYBOARD / 00:26-01:00

Haz visible el resultado

Mantén acciones simples y lectura clara. El espectador debe entender qué cambió.


---

## Página 03: Haz visible el resultado


00:26-00:34  /  La edición

**Plano y acción.** Abre Edición. En una captura real, selecciona una toma, coloca el cabezal y divide. Acerca el plano al resultado; si la mueves, muestra que desbloqueaste Hold.

**Locución.** “En Edición, corta, acomoda y organiza cada parte.”

**Texto en pantalla.** DALE FORMA A TU TOMA

00:34-00:43  /  El sonido

**Plano y acción.** Abre FX de la misma voz. Enseña tonalidad correcta y un ajuste pequeño de reverb. Alterna 2 segundos de voz seca y 2 segundos con FX al mismo volumen.

**Locución.** “Ajusta afinación, ecualización, compresión, delay y reverb. Escucha la diferencia.”

**Texto en pantalla.** TU VOZ / TU SONIDO

00:43-00:52  /  La entrega

**Plano y acción.** Captura Descargar archivo (.rgodbeat). Con un pase activo real, abre EXPORTAR PROYECTO y muestra WAV y stems. Usa una descarga verdadera; no fabriques el mensaje de éxito.

**Locución.** “Guarda tu proyecto. Con un pase activo, exporta tu mezcla WAV y tus voces por separado.”

**Texto en pantalla.** GUARDA + EXPORTA
Exportación de audio con pase activo

00:52-01:00  /  La invitación

**Plano y acción.** Plano de ambiente o cierre limpio con el logo original añadido en montaje. Deja la ruta de Studio al menos los últimos 3 segundos, sin animación que dificulte leerla.

**Locución.** “De la idea a tu próxima canción. Empieza en RGodbeat Studio.”

**Texto en pantalla.** EMPIEZA EN STUDIO / rgodbeat.com/studio

PROMPTS / PLANOS DE AMBIENTE

Genera el ambiente con IA

Prompts en inglés para copiar; la locución y los rótulos finales se mantienen en español.


---

## Página 04: Genera el ambiente con IA


A / Apertura de micrófono

**PROMPT PARA COPIAR**
Cinematic close-up of a real studio microphone and wired headphones on a graphite desk, warm amber side light, subtle violet background glow, intimate independent music studio at night. Slow controlled camera push-in, shallow depth of field, realistic materials, premium music product film. Leave clean dark negative space on the left for a title added later. No text, no logos, no interface, no dialogue, no music.

B / Plano de manos opcional

**PROMPT PARA COPIAR**
Close-up of an adult music artist placing wired headphones beside a microphone in the same graphite studio, warm amber light from camera right, subtle violet background. Natural hand movement, physically correct fingers, calm confident mood, stable camera, realistic commercial cinematography. Do not show readable device screens. No text, no logos, no dialogue, no generated music.

C / Cierre de marca

**PROMPT PARA COPIAR**
Minimal cinematic graphite studio background with a soft warm amber light reflection and a subtle violet edge light. Slow almost imperceptible camera drift, elegant restrained atmosphere, clean center and lower area reserved for a logo and call to action added in editing. No text, no logos, no interface, no people, no dialogue, no music.

**Continuidad:** conserva dirección de luz, escritorio y paleta entre planos. Usa la misma imagen de referencia si tu herramienta lo permite. Genera variantes y selecciona la más natural; la duración final se fija en el montaje.

IA / ENSAMBLAJE

Cómo llevarlo a Flow o similar

Flujo adaptable. Verifica qué controles de video y referencias ofrece tu modelo antes de generar.


---

## Página 05: Cómo llevarlo a Flow o similar


01  **Crea el proyecto y define el formato**

En Google Flow abre o crea un proyecto, selecciona Video y revisa relación de aspecto y duración. Genera la apertura y el cierre como clips independientes. [1]

02  **Añade referencias coherentes**

Cuando estén disponibles, usa Ingredients para mantener objetos/estilo o Frames para definir el inicio/final. Añade un prompt que describa la acción y complemente la imagen. [1]

03  **Graba la app fuera del generador**

Registra las acciones de las escenas 2-7 en Studio. Importa esas grabaciones al editor de video que uses; no pidas al modelo recrear menús, textos o resultados de la aplicación.

04  **Monta, mezcla y subtitula**

Ordena los clips con los tiempos del storyboard. Añade la voz, el instrumental, los rótulos exactos, el logo y los subtítulos del kit. La disponibilidad de funciones de Flow puede variar; el montaje final puede hacerse en otro editor.

**Prompt maestro para una IA de guion o edición**
Usa esta guía como fuente de verdad para producir un demo de RGodbeat Studio de 60 segundos en español, 16:9. Respeta los ocho bloques del storyboard y la locución. Utiliza mis capturas reales para toda interacción con la app; genera solo los planos de ambiente. Mantén negro/grafito, luz ámbar y detalles morados. Añade el logo original y los rótulos en edición. Indica que exportar audio requiere un pase activo. No inventes controles, precios, resultados, compatibilidad ni una publicación exitosa. Entrega lista de clips, orden de montaje y tareas pendientes con los materiales que falten.

[1] Google Flow Help, “Create videos in Google Flow”. Fuente oficial consultada el 10/10/2026. Enlace completo en la página 7.

AUDIO / ADAPTACIONES

Locución lista para producir

Voz cercana y segura, español latino neutro. Ritmo natural, sin estilo de anuncio exagerado.


---

## Página 06: Locución lista para producir


**00:00-00:05**  Esa idea que tienes merece escucharse.

**00:05-00:11**  RGodbeat Studio reúne tu beat y tu voz en un mismo espacio.

**00:11-00:18**  Elige una pista del catálogo o carga tu propio instrumental.

**00:18-00:26**  Selecciona tu canal, activa el conteo y graba tu primera toma.

**00:26-00:34**  En Edición, corta, acomoda y organiza cada parte.

**00:34-00:43**  Ajusta afinación, ecualización, compresión, delay y reverb. Escucha la diferencia.

**00:43-00:52**  Guarda tu proyecto. Con un pase activo, exporta tu mezcla WAV y tus voces por separado.

**00:52-01:00**  De la idea a tu próxima canción. Empieza en RGodbeat Studio.

Versión vertical de 15 segundos

**0-3 s:** “Tu beat. Tu voz.” + micrófono. **3-7 s:** captura de REC. **7-11 s:** edición y FX, una acción por plano. **11-15 s:** logo + “Empieza en RGodbeat Studio” + ruta. Este recorte puede centrarse en crear; si muestra exportación, conserva la condición de pase activo.

Cuatro piezas educativas

1. Cargar un instrumental y revisar su BPM. 2. Grabar una primera voz con conteo. 3. Cortar una toma y usar Hold. 4. Diferencia entre proyecto .rgodbeat, master WAV y stems. Cada pieza demuestra una sola acción real.

**Sonido del demo**
Durante el antes/después de FX deja respirar la voz musical. Baja la locución y la música de fondo para que el cambio sea audible. El SRT incluido es una base de tiempos: ajústalo a la interpretación final y revisa la pronunciación de RGodbeat.

ENTREGA / VERIFICACIÓN

Antes de publicar

Una revisión final mantiene coherencia entre lo que enseñas y lo que la app permite hacer.


---

## Página 07: Antes de publicar


| REVISIÓN | CRITERIO DE ENTREGA |
| --- | --- |
| Producto | Botones y pantallas reales, nombres correctos, pase activo para demostrar exportación/multipista. No señales una descarga como exitosa sin comprobar el archivo. |
| Imagen | Cursor visible cuando aporte claridad, zoom moderado, textos nítidos, logo original. En vertical, usa encuadres específicos para cada control. |
| Audio | Voz inteligible, beat autorizado y comparación de FX al mismo volumen. Sin saturación, saltos bruscos o tomas sintéticas en el anuncio final. |
| Montaje | Duración cercana a 60 s, ritmo claro, subtítulos sincronizados y CTA legible durante al menos 3 s. Revisa la ruta pública antes de lanzar la campaña. |

Fuentes y alcance

**Producto:** componentes StudioApp, TopBar, LoadBeatModal, TimelineWorkspace, VocalFXModal y ExportModal; módulos de guardado local y nube; API de acceso. Revisados en el repositorio rgodbeat-v2 el 10/10/2026. No se probaron compras, guardados de cuenta ni publicaciones reales para crear esta guía.

**[1] Fuente oficial de Flow:**
support.google.com/flow/answer/16353334
Respalda la creación por prompts y el uso de Ingredients/Frames. Los parámetros de cámara, la duración de 60 segundos y el montaje aquí propuestos son dirección creativa para RGodbeat.

**Kit editable**
Guion y prompts en Markdown, subtítulos SRT de referencia, cuatro capturas PNG y el logo original. Las capturas de prueba no acreditan acceso premium ni una exportación real.